--------------
share/wake/lib
--------------

.. toctree::
	system/system.rst
	core/core.rst


