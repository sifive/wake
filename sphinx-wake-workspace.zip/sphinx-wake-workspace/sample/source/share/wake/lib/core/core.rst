-------------------
share/wake/lib/core
-------------------

.. toctree::


regexp.wake
-----------
.. wake:function:: def quote str

	quote: (str: String) => RegExp
	Turns a String into a properly quoted Regular Expression
	

	Parameters: ``str: String``

	Return Type: ``RegExp``

.. wake:function:: def regExpCat l

	Concatenates all elements of a list of ``RegExp``s.
	

	Parameters: ``l: List RegExp``

	Return Type: ``RegExp``

.. wake:function:: def stringToRegExp str

	Converts a ``String`` to a ``RegExp``.
	

	Parameters: ``str: String``

	Return Type: ``Result RegExp String``

.. wake:function:: def regExpToString regexp

	Converts a ``RegExp`` to a ``String``.
	

	Parameters: ``regexp: RegExp``

	Return Type: ``String``

.. wake:function:: def matches testRegexp str

	Returns ``True`` if ``str`` matches the regular expression ``testRegexp``, otherwise ``False``.
	

	Parameters: ``testRegexp: RegExp,  str: String``

	Return Type: ``Boolean``

.. wake:function:: def extract parensRegexp str

	Extracts all instances in ``str`` matching ``parensRegexp``.  Returns Nil if no matches are found.
	

	Parameters: ``parensRegexp: RegExp,  str: String``

	Return Type: ``List String``

.. wake:function:: def replace locatorRegexp replacement str

	Replaces all instances matching ``locatorRegExpr`` in ``str`` with ``replacement``.
	

	Parameters: ``locatorRegexp: RegExp,  replacement: String,  str: String``

	Return Type: ``String``

.. wake:function:: def tokenize seperatorRegexp str

	Tokenizes ``str`` into a list of tokens, using ``separatorRegexp`` as a divider.
	

	Parameters: ``seperatorRegexp: RegExp,  str: String``

	Return Type: ``List String``

result.wake
-----------
.. wake:data:: data Result pass fail

	Datatype either stores a ``Pass`` or ``Fail``, depending on result of a test.
	

.. wake:function:: def isPass

	Returns ``True`` if passed, ``False`` if failed.
	

	Parameters: ``Result a b``

	Return Type: ``Boolean``

.. wake:function:: def isFail

	Returns ``True`` if failed, ``False`` if passed.
	

	Parameters: ``Result a b``

	Return Type: ``Boolean``

.. wake:function:: def getPass

	Returns value if passed, ``None`` if failed.
	

	Parameters: ``Result a b``

	Return Type: ``Option a``

.. wake:function:: def getFail

	Returns value if failed, ``None`` if passed.
	

	Parameters: ``Result a b``

	Return Type: ``Option b``

.. wake:function:: def getWhenFail fail

	Returns value if passed, ``fail`` if failed.
	

	Parameters: ``fail: a,  Result a b``

	Return Type: ``a``

.. wake:function:: def rmap fn

	Maps function ``fn`` to the value, if passed.
	

	Parameters: ``fn: a,  b,  Result a c``

	Return Type: ``Result b c``

.. wake:function:: def rmapPass fn

	(fn: a => Result b c) => Result a c => Result b c
	Applies a fallible function to Pass value or propogates Fail
	

	Parameters: ``fn: a,  Result b c,  Result a c``

	Return Type: ``Result b c``

.. wake:function:: def rmapFail fn

	(fn: a => Result b c) => Result b a => Result b c
	Applies a fallible function to Fail value or propogates Pass
	

	Parameters: ``fn: a,  Result b c,  Result b a``

	Return Type: ``Result b c``

.. wake:function:: def findFail

	List (Result a b) => Result (List a) b
	Finds the first Fail in a List of Result or aggregates Passes into a List
	

	Parameters: ``List Result a b``

	Return Type: ``Result (List a) b``

.. wake:function:: def findFailFn fn

	(fn: a => Result b c) => List a => Result (List b) c
	returning the first Fail or aggregates the Passes into a List
	Applies a fallible function to each element of a List,
	

	Parameters: ``fn: a,  Result b c,  List a``

	Return Type: ``Result (List b) c``

.. wake:function:: def findPass

	List (Result a b) => Result a (List b)
	Finds the first Pass in a List of Result or aggregates Fails into a List
	

	Parameters: ``List Result a b``

	Return Type: ``Result a (List b)``

.. wake:function:: def findPassFn fn

	(fn: a => Result b c) => List a => Result b (List c)
	returning the first Pass or aggregates the Fails into a List
	Applies a fallible function to each element of a List
	

	Parameters: ``fn: a,  Result b c,  List a``

	Return Type: ``Result b (List c)``

.. wake:function:: def panic s

	No description for this feature yet.

	Parameters: ``s: String``

	Return Type: ``a``

.. wake:function:: def stack s

	No description for this feature yet.

	Parameters: ``s: Unit``

	Return Type: ``List String``

.. wake:tuple:: tuple Error

	``Stack`` traces back to the original source of the ``Error``.
	``Cause`` describes why the ``Error`` occurred.
	``Error`` type has two attributes:
	

	Parameters: ``Stack: List String,  Error``

	Return Type: ``Error``

.. wake:function:: def makeError cause

	No description for this feature yet.

	Parameters: ``cause: String``

	Return Type: ``Error``

option.wake
-----------
.. wake:data:: data Option a

	The ``Option`` datatype.  Either holds a valid entry with value ``a`` (``Some``), or nothing (``None``).
	

.. wake:function:: def isSome

	Returns ``True`` if the :wake:reref:`Option` contains a value, or ``False`` if it is empty.
	

	Parameters: ``Option a``

	Return Type: ``Boolean``

.. wake:function:: def isNone

	Returns ``True`` if the :wake:reref:`Option` is empty, ``False`` otherwise.
	

	Parameters: ``Option a``

	Return Type: ``Boolean``

.. wake:function:: def getOrElse b

	Returns the :wake:reref:`Option` 's value if it is exists, or ``b`` if the :wake:reref:`Option` is empty.
	

	Parameters: ``b: a,  Option a``

	Return Type: ``a``

.. wake:function:: def orElse

	In this case, returns ``x`` if it exists, otherwise ``z``.  Returns ``None`` if both are empty.
	Inteded use: ``int "x" | orElse (int "z") | getOrElse 4``
	

	Parameters: ``Option a,  Option a``

	Return Type: ``Option a``

.. wake:function:: def getOrElseFn fn

	(fn: Unit => a) => Option a => a
	Returns the Option's value if Some, otherwise returns the result of fn
	

	Parameters: ``fn: Unit,  a,  Option a``

	Return Type: ``a``

.. wake:function:: def omap f

	Either returns an Option containing result of invoking f on the Option's value if it exists, or None if the Option is empty.
	

	Parameters: ``f: a,  b,  Option a``

	Return Type: ``Option b``

.. wake:function:: def omapPartial f

	Unlike omap, it does not return an Option, but just the value itself, unless it is None.
	Either returns the result of invoking f on the Option's value if it exists, or None if the Option is empty.
	

	Parameters: ``f: a,  Option b,  Option a``

	Return Type: ``Option b``

.. wake:function:: def ofilter f

	Either returns the original Option if its value satisfies the function f, otherwise it returns None.
	

	Parameters: ``f: a,  Boolean,  Option a``

	Return Type: ``Option a``

.. wake:function:: def findSome

	List (Option a) => Option a
	Finds the first Some in a List of Option or returns None if List is all None
	

	Parameters: ``List Option a``

	Return Type: ``Option a``

.. wake:function:: def findSomeFn fn

	(fn: a => Option b) => List a => Option b
	returning the first Some or a None
	Applies a function that returns Option to each element of a List
	

	Parameters: ``fn: a,  Option b,  List a``

	Return Type: ``Option b``

.. wake:function:: def findNone

	List (Option a) => Option (List a)
	If a List of Options is all Some, returns Some of the elements, otherwise None
	

	Parameters: ``List Option a``

	Return Type: ``Option (List a)``

.. wake:function:: def findNoneFn fn

	(fn: a => Option b) => List a => Option (List b)
	returning None if any result is None, otherwise aggregates the Somes into a List
	Applies a function that returns Option to each element of a List
	

	Parameters: ``fn: a,  Option b,  List a``

	Return Type: ``Option (List b)``

.. wake:function:: def getOrFail f

	(f: a) => Option b => Result b a
	Converts Some to Pass or Fail
	

	Parameters: ``f: a,  Option b``

	Return Type: ``Result b a``

.. wake:function:: def getOrFailFn fn

	(fn: Unit => a) => Option b => Result b a
	Converts Some to Pass or Fail of output of fn
	

	Parameters: ``fn: Unit,  a,  Option b``

	Return Type: ``Result b a``

.. wake:function:: def getOrPass p

	(p: a) => Option b => Result a b
	Converts Some to Fail or Pass
	

	Parameters: ``p: a,  Option b``

	Return Type: ``Result a b``

.. wake:function:: def getOrPassFn fn

	(fn: Unit => a) => Option b => Result a b
	Converts Some to Fail or Pass of output of fn
	

	Parameters: ``fn: Unit,  a,  Option b``

	Return Type: ``Result a b``

syntax.wake
-----------
.. wake:function:: def argument . memberFn

	Flip function and object order
	

	Parameters: ``argument: a,  memberFn: a,  b``

	Return Type: ``b``

.. wake:function:: def argument | pipeFn

	No description for this feature yet.

	Parameters: ``argument: a,  pipeFn: a,  b``

	Return Type: ``b``

.. wake:function:: def dollarFn $ argument

	Avoid ()s without changing order
	

	Parameters: ``dollarFn: a,  b,  argument: a``

	Return Type: ``b``

.. wake:function:: def f ∘ g

	The ring operator is used to denote the composition of functions.
	

	Parameters: ``f: a,  b,  g: c,  a,  x: c``

	Return Type: ``b``

.. wake:function:: def flip f x y

	Allows flipping the parameters of a function.
	

	Parameters: ``f: a,  b,  c,  x: b,  y: a``

	Return Type: ``c``

boolean.wake
------------
.. wake:data:: data Boolean

	``Boolean`` type has two values: ``True`` and ``False``.
	

.. wake:function:: def !x

	Unary operator for NOT.
	

	Parameters: ``x: Boolean``

	Return Type: ``Boolean``

.. wake:function:: def x && y

	Binary operator for AND.
	

	Parameters: ``x: Boolean,  y: Boolean``

	Return Type: ``Boolean``

.. wake:function:: def x || y

	Binary operator for OR.
	

	Parameters: ``x: Boolean,  y: Boolean``

	Return Type: ``Boolean``

integer.wake
------------
.. wake:function:: def +x

	Unary positive sign operator for Integers.
	

	Parameters: ``x: a``

	Return Type: ``a``

.. wake:function:: def -x

	Unary negative sign operator for Integers.
	

	Parameters: ``x: Integer``

	Return Type: ``Integer``

.. wake:function:: def ~x

	Unary two's complement operator for Integers.
	

	Parameters: ``x: Integer``

	Return Type: ``Integer``

.. wake:function:: def x + y

	Binary addition operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def x - y

	Binary subtraction operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def x * y

	Binary multiplication operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def x / y

	Binary division operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def x % y

	Binary remainder operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def x << y

	Binary left shift operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def x >> y

	Binary right shift operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def x ^ y

	Binary exponentiation operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def root x n

	Returns the nth root of x.
	

	Parameters: ``x: Integer,  n: Integer``

	Return Type: ``Integer``

.. wake:function:: def sqrt x

	Unary square root operator.
	

	Parameters: ``x: Integer``

	Return Type: ``Integer``

.. wake:function:: def abs x

	Unary absolute-value operator.
	

	Parameters: ``x: Integer``

	Return Type: ``Integer``

.. wake:function:: def xor x y

	Binary bitwise XOR operator.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def and x y

	Binary bitwise AND operator.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def or  x y

	Binary bitwise OR operator.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def gcd x y

	Greatest Common Divisor.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def lcm x y

	Least Common Multiple.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def powm x y m

	Computes (x^y) % m.
	

	Parameters: ``x: Integer,  y: Integer,  m: Integer``

	Return Type: ``Integer``

.. wake:function:: def icmp x y

	No description for this feature yet.

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Order``

.. wake:function:: def x <=> y

	No description for this feature yet.

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Order``

.. wake:function:: def x <  y

	Binary Less-Than operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Boolean``

.. wake:function:: def x >  y

	Binary Greater-Than operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Boolean``

.. wake:function:: def x >= y

	Binary Greater-Or-Equal operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Boolean``

.. wake:function:: def x <= y

	Binary Less-Or-Equal operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Boolean``

.. wake:function:: def x == y

	Binary Is-Equal operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Boolean``

.. wake:function:: def x != y

	Binary Not-Equal operator for Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Boolean``

.. wake:function:: def min x y

	Calculates the minimum of two Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def max x y

	Calculates the maximum of two Integers.
	

	Parameters: ``x: Integer,  y: Integer``

	Return Type: ``Integer``

.. wake:function:: def ∏ l

	Calculates the product of a list of integers.
	

	Parameters: ``l: List Integer``

	Return Type: ``Integer``

.. wake:function:: def ∑ l

	Calculates the sum of a list of integers.
	

	Parameters: ``l: List Integer``

	Return Type: ``Integer``

double.wake
-----------
.. wake:function:: def dabs x

	Unary absolute value operator for a ``Double``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def   -. x

	Unary negative sign for a ``Double``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def   +. x

	Unary positive sign for a ``Double``.
	

	Parameters: ``x: a``

	Return Type: ``a``

.. wake:function:: def x +. y

	Binary addition operator for ``Double`` s.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def x -. y

	Binary subtraction operator for ``Double`` s.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def x *. y

	Binary multiplication operator for ``Double`` s.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def x /. y

	Binary division operator for ``Double`` s.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def x ^. y

	Binary exponentiation operator for ``Double`` s.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def dfma x y z

	Computes ``x*y + z``.
	

	Parameters: ``x: Double,  y: Double,  z: Double``

	Return Type: ``Double``

.. wake:function:: def droot n

	Creates a function that computes the ``n`` th root.
	

	Parameters: ``n: Double,  Double``

	Return Type: ``Double``

.. wake:function:: def dsqrt

	Unary operator for square root.
	

	Parameters: ``Double``

	Return Type: ``Double``

.. wake:function:: def √ x

	Unary operator for square root, using the Unicode character.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def ∛ x

	Unary operator for cube root.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def ∜ x

	Unary operator for fourth root.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dcmp x y

	No description for this feature yet.

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Order``

.. wake:function:: def x <=>. y

	No description for this feature yet.

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Order``

.. wake:function:: def x <.  y

	Binary Less-Than Operator.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Boolean``

.. wake:function:: def x >.  y

	Binary Greater-Than Operator.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Boolean``

.. wake:function:: def x >=. y

	Binary Greater-Or-Equal Operator.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Boolean``

.. wake:function:: def x <=. y

	Binary Less-Or-Equal Operator.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Boolean``

.. wake:function:: def x ==. y

	Binary Equal-To Operator.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Boolean``

.. wake:function:: def x !=. y

	Binary Not-Equal Operator.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Boolean``

.. wake:function:: def dmin x y

	Computes the minimum of two ``Double`` s.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def dmax x y

	Computes the maximum of two ``Double`` s.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def ∏. l

	Product of a series of ``Double`` s.
	

	Parameters: ``l: List Double``

	Return Type: ``Double``

.. wake:function:: def ∑. l

	Sum of a series of ``Double`` s.
	

	Parameters: ``l: List Double``

	Return Type: ``Double``

.. wake:data:: data DoubleFormat

	No description for this feature yet.

.. wake:function:: def dformat x

	No description for this feature yet.

	Parameters: ``x: DoubleFormat,  p: Integer,  x: Double``

	Return Type: ``String``

.. wake:function:: def double s

	No description for this feature yet.

	Parameters: ``s: String``

	Return Type: ``Option Double``

.. wake:function:: def dhex

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``String``

.. wake:function:: def dstr

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``String``

.. wake:function:: def dint x

	No description for this feature yet.

	Parameters: ``x: Integer``

	Return Type: ``Option Double``

.. wake:data:: data DoubleClass

	Conversion methods
	

.. wake:function:: def dclass x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``DoubleClass``

.. wake:function:: def dfrexp x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Pair Double Integer``

.. wake:function:: def dldexp f e

	No description for this feature yet.

	Parameters: ``f: Double,  e: Integer``

	Return Type: ``Double``

.. wake:function:: def dmodf  x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Pair Integer Double``

.. wake:function:: def idouble x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Option Integer``

.. wake:function:: def dcos    x

	Calculates the cosine of a ``Double``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dsin    x

	Calculates the sine of a ``Double``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dtan    x

	Calculates the tangent of a ``Double``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dacos   x

	Calculates the inverse cosine of a ``Double``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dasin   x

	Calculates the inverse sine of a ``Double``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dexp    x

	Calculates e^x.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dlog    x

	Calculates the natural logarithm of ``x``.
	

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dexpm1  x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dlog1p  x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def derf    x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def derfc   x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dtgamma x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def dlgamma x

	No description for this feature yet.

	Parameters: ``x: Double``

	Return Type: ``Double``

.. wake:function:: def datan x y

	Calculates the inverse tangent of ``y/x``, giving the angle of the point (``x``, ``y``) in the coordinate plane.
	

	Parameters: ``x: Double,  y: Double``

	Return Type: ``Double``

.. wake:function:: def nan

	Not a Number
	

	Parameters: None

	Return Type: ``Double``

.. wake:function:: def inf

	Infinity
	

	Parameters: None

	Return Type: ``Double``

.. wake:function:: def pi

	Pi
	

	Parameters: None

	Return Type: ``Double``

vector.wake
-----------
.. wake:function:: def listToVector l

	Converts a ``List`` to a ``Vector``.
	

	Parameters: ``l: List a``

	Return Type: ``Vector a``

.. wake:function:: def treeToVector t

	Converts a ``Tree`` to a ``Vector``.
	

	Parameters: ``t: Tree a``

	Return Type: ``Vector a``

.. wake:function:: def vempty (Vector _ s e)

	Returns ``True`` if the ``Vector`` has no entries, otherwise ``False``.
	

	Parameters: ``Vector a``

	Return Type: ``Boolean``

.. wake:function:: def vlen (Vector _ s e)

	Returns the length of the ``Vector``.
	

	Parameters: ``Vector a``

	Return Type: ``Integer``

.. wake:function:: def vectorToList

	Converts a ``List`` to a ``Vector``.
	

	Parameters: ``v: Vector a``

	Return Type: ``List a``

.. wake:function:: def vsplitAt i (Vector v s e)

	The ``i``th entry will end up in the second ``Vector``, provided that ``0 <= i < vlen(v)``.
	Splits the ``Vector`` into two vectors, at the point ``i``.
	

	Parameters: ``Integer,  Vector a``

	Return Type: ``Pair (Vector a) (Vector a)``

.. wake:function:: def vtake i v

	Returns the first ``i`` elements of the ``Vector``.
	

	Parameters: ``i: Integer,  v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vdrop i v

	Removes the first ``i`` elements of the ``Vector``.
	

	Parameters: ``i: Integer,  v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vat i (Vector v s e)

	Returns an ``Option``, containing either the ``i``th element of the vector, or ``None`` if ``i`` is out of range.
	

	Parameters: ``Integer,  Vector a``

	Return Type: ``Option a``

.. wake:function:: def vmap f v

	Calls a function on every entry of a ``Vector``.
	

	Parameters: ``f: a,  b,  v: Vector a``

	Return Type: ``Vector b``

.. wake:function:: def vseq n

	No description for this feature yet.

	Parameters: ``n: Integer``

	Return Type: ``Vector Integer``

.. wake:function:: def vzip a b

	No description for this feature yet.

	Parameters: ``a: Vector a,  b: Vector b``

	Return Type: ``Vector (Pair a b)``

.. wake:function:: def vunzip v

	No description for this feature yet.

	Parameters: ``v: Vector Pair a b``

	Return Type: ``Pair (Vector a) (Vector b)``

.. wake:function:: def vreverse v

	Returns a ``Vector``, with the order of the elements reversed.
	

	Parameters: ``v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vfoldl f a v

	Uses the binary function ``f`` to aggregate all the elements of the ``Vector``, from left to right.
	

	Parameters: ``f: a,  b,  a,  a: a,  v: Vector b``

	Return Type: ``a``

.. wake:function:: def vfoldr f a v

	Uses the binary function ``f`` to aggregate all the elements of the ``Vector``, from right to left.
	

	Parameters: ``f: a,  b,  b,  a: b,  v: Vector a``

	Return Type: ``b``

.. wake:function:: def vfoldmap f a g v

	No description for this feature yet.

	Parameters: ``f: a,  a,  a,  a: a,  g: b,  a,  v: Vector b``

	Return Type: ``a``

.. wake:function:: def vfold f a v

	No description for this feature yet.

	Parameters: ``f: a,  a,  a,  a: a,  v: Vector a``

	Return Type: ``a``

.. wake:function:: def vfind f v

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  v: Vector a``

	Return Type: ``Option (Pair a Integer)``

.. wake:function:: def vsplitUntil f v

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  v: Vector a``

	Return Type: ``Pair (Vector a) (Vector a)``

.. wake:function:: def vtakeUntil f t

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  t: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vdropUntil f t

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  t: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vexists f t

	Returns True if there exists an x where f x = True
	

	Parameters: ``f: a,  Boolean,  t: Vector a``

	Return Type: ``Boolean``

.. wake:function:: def vforall f t

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  t: Vector a``

	Return Type: ``Boolean``

.. wake:function:: def vsplitBy f v

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  v: Vector a``

	Return Type: ``Pair (Vector a) (Vector a)``

.. wake:function:: def vfilter f v

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vunfoldl f a n

	No description for this feature yet.

	Parameters: ``f: a,  Pair a b,  a: a,  n: Integer``

	Return Type: ``Vector b``

.. wake:function:: def vscanl f a v

	No description for this feature yet.

	Parameters: ``f: a,  b,  a,  a: a,  v: Vector b``

	Return Type: ``Vector a``

.. wake:function:: def vscanr f a v

	No description for this feature yet.

	Parameters: ``f: a,  b,  b,  a: b,  v: Vector a``

	Return Type: ``Vector b``

.. wake:function:: def vscanmap f a g v

	f called exactly once per input
	vscan = O(n), log n deep prefix-sum
	

	Parameters: ``f: a,  a,  a,  a: a,  g: b,  a,  v: Vector b``

	Return Type: ``Vector a``

.. wake:function:: def vscan f a v

	No description for this feature yet.

	Parameters: ``f: a,  a,  a,  a: a,  v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vsortBy lt v

	Merge-sort, if sorted then O(n) else O(nlogn)
	

	Parameters: ``lt: a,  a,  Boolean,  v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vdistinctBy cmp v

	No description for this feature yet.

	Parameters: ``cmp: a,  a,  Order,  v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vdistinctRunBy eq v

	No description for this feature yet.

	Parameters: ``eq: a,  a,  Boolean,  v: Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vcmp f l r

	No description for this feature yet.

	Parameters: ``f: a,  b,  Order,  l: Vector a,  r: Vector b``

	Return Type: ``Order``

.. wake:function:: def vtranspose v

	No description for this feature yet.

	Parameters: ``v: Vector Vector a``

	Return Type: ``Vector (Vector a)``

.. wake:function:: def vflatten vo

	No description for this feature yet.

	Parameters: ``vo: Vector Vector a``

	Return Type: ``Vector a``

.. wake:function:: def vtab f n

	Simple parallel construction
	

	Parameters: ``f: Integer,  a,  n: Integer``

	Return Type: ``Vector a``

string.wake
-----------
.. wake:function:: def cat strings

	Concatenates a ``List`` of ``String``s.
	

	Parameters: ``strings: List String``

	Return Type: ``String``

.. wake:function:: def catWith separator strings

	Concatenates a ``List`` of ``String``s, placing a specified separator between every consecutive pair of entries.
	

	Parameters: ``separator: String,  strings: List String``

	Return Type: ``String``

.. wake:function:: def explode str

	String => List String of codepoints
	

	Parameters: ``str: String``

	Return Type: ``List String``

.. wake:function:: def strbase base n

	Converts an ``Integer`` to a ``String`` representation in a specified base.
	

	Parameters: ``base: Integer,  n: Integer``

	Return Type: ``String``

.. wake:function:: def intbase base s

	Converts a ``String`` to an ``Integer`` representation, reading the ``String`` in a specified base.
	

	Parameters: ``base: Integer,  s: String``

	Return Type: ``Option Integer``

.. wake:function:: def str n

	Converts a ``String`` to a base-10 ``Integer``.
	

	Parameters: ``n: Integer``

	Return Type: ``String``

.. wake:function:: def int s

	Converts a base-10 ``Integer`` to a ``String``.
	

	Parameters: ``s: String``

	Return Type: ``Option Integer``

.. wake:function:: def integerToUnicode i

	Converts an ``Integer`` to a Unicode ``String``.
	

	Parameters: ``i: Integer``

	Return Type: ``String``

.. wake:function:: def unicodeToInteger s

	Converts a Unicode ``String`` to an ``Integer``.
	

	Parameters: ``s: String``

	Return Type: ``Integer``

.. wake:function:: def integerToByte i

	String <=> Integer Binary conversion (Warning: may create invalid Unicode)
	

	Parameters: ``i: Integer``

	Return Type: ``String``

.. wake:function:: def byteToInteger s

	No description for this feature yet.

	Parameters: ``s: String``

	Return Type: ``Integer``

.. wake:function:: def version

	Version of wake
	

	Parameters: None

	Return Type: ``String``

.. wake:function:: def unicodeCanonical  x

	Unicode normalization methods
	

	Parameters: ``x: String``

	Return Type: ``String``

.. wake:function:: def unicodeIdentifier x

	No description for this feature yet.

	Parameters: ``x: String``

	Return Type: ``String``

.. wake:function:: def unicodeLowercase  x

	No description for this feature yet.

	Parameters: ``x: String``

	Return Type: ``String``

.. wake:function:: def scmpCanonical x y

	Unicode NFC string comparison Ç == C+◌̧
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Order``

.. wake:function:: def scmpIdentifier x y

	Unicode NFKC string comparison (¼i⁹ = 1/4i9)
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Order``

.. wake:function:: def scmpLowercase x y

	Unicode case insensitive NFKC comparison
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Order``

.. wake:function:: def scmp x y

	Raw binary string comparison; no normalization performed
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Order``

.. wake:function:: def x <=>~y

	This is the string order you should probably be using
	NFKC order (fancy format removed) -- secure default
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Order``

.. wake:function:: def x <~  y

	Returns True if x is less than y.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x >~  y

	Returns True if x is greater than y.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x >=~ y

	Returns True if x is greater than or equal to y.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x <=~ y

	Returns True if x is less than or equal to y.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x ==~ y

	Returns True if x is equal to y.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x !=~ y

	Returns True if x is not equal to y.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x <=>^y

	Case insensitive order (^ = capitals ignored)
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Order``

.. wake:function:: def x <^  y

	Returns True if x is less than y, ignoring case.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x >^  y

	Returns True if x is greater than y, ignoring case.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x >=^ y

	Returns True if x is greater than or equal to y, ignoring case.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x <=^ y

	Returns True if x is less than or equal to y, ignoring case.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x ==^ y

	Returns True if x is equal to y, ignoring case.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x !=^ y

	Returns True if x is not equal to y, ignoring case.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x <=>*y

	Only use this for non-textual data
	Raw binary string order
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Order``

.. wake:function:: def x <*  y

	Returns True if x is less than y, in raw binary representation.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x >*  y

	Returns True if x is greater than y, in raw binary representation.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x >=* y

	Returns True if x is greater than or equal to y, in raw binary representation.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x <=* y

	Returns True if x is less than or equal to y, in raw binary representation.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x ==* y

	Returns True if x is equal to y, in raw binary representation.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

.. wake:function:: def x !=* y

	Returns True if x is not equal to y, in raw binary representation.
	

	Parameters: ``x: String,  y: String``

	Return Type: ``Boolean``

print.wake
----------
.. wake:function:: def format any

	Any => String conversion
	

	Parameters: ``any: a``

	Return Type: ``String``

.. wake:data:: data LogLevel

	-dv     => Debug
	-v      => Verbose
	-q      => Quiet
	-d      => Normal
	default => Normal
	These values often come from the wake command-line
	

.. wake:data:: data EchoTarget

	No description for this feature yet.

.. wake:function:: def logError

	No description for this feature yet.

	Parameters: ``LogLevel``

	Return Type: ``EchoTarget``

.. wake:function:: def logWarn

	No description for this feature yet.

	Parameters: ``LogLevel``

	Return Type: ``EchoTarget``

.. wake:function:: def logNormal

	No description for this feature yet.

	Parameters: ``LogLevel``

	Return Type: ``EchoTarget``

.. wake:function:: def logVerbose

	No description for this feature yet.

	Parameters: ``LogLevel``

	Return Type: ``EchoTarget``

.. wake:function:: def logDebug

	No description for this feature yet.

	Parameters: ``LogLevel``

	Return Type: ``EchoTarget``

.. wake:function:: def logNever

	No description for this feature yet.

	Parameters: ``LogLevel``

	Return Type: ``EchoTarget``

.. wake:function:: def printLevel logLevelFn

	Print with a given verbosity
	

	Parameters: ``logLevelFn: LogLevel,  EchoTarget,  outputStr: String``

	Return Type: ``Unit``

.. wake:function:: def printlnLevel logLevelFn

	No description for this feature yet.

	Parameters: ``logLevelFn: LogLevel,  EchoTarget,  outputStr: String``

	Return Type: ``Unit``

.. wake:function:: def print

	Print any type to stdout; even exceptions
	

	Parameters: ``outputStr: String``

	Return Type: ``Unit``

.. wake:function:: def println

	No description for this feature yet.

	Parameters: ``outputStr: String``

	Return Type: ``Unit``

.. wake:function:: def waitOne f x

	Eg: x = 1, 2, 3, Nil; waitOne f x waits for ',' to be known vs. Nil
	Wait for the top of a value to be made available, then run (f x)
	

	Parameters: ``f: a,  b,  x: a``

	Return Type: ``b``

.. wake:function:: def waitAll f x

	Eg: x = 1, 2, 3, Nil; waitAll f x waits for all the values 1-3 to be known
	Wait for all of a value to be made available, then run (f x)
	

	Parameters: ``f: a,  b,  x: a``

	Return Type: ``b``

tree.wake
---------
.. wake:function:: def tnew cmp

	Create a new Tree, sorted by cmp.
	

	Parameters: ``cmp: a,  a,  Order``

	Return Type: ``Tree a``

.. wake:function:: def listToTree cmp list

	Convert a List to a Tree.
	

	Parameters: ``cmp: a,  a,  Order,  list: List a``

	Return Type: ``Tree a``

.. wake:function:: def listToTreeMulti cmp list

	No description for this feature yet.

	Parameters: ``cmp: a,  a,  Order,  list: List a``

	Return Type: ``Tree a``

.. wake:function:: def vectorToTreeMulti cmp v

	No description for this feature yet.

	Parameters: ``cmp: a,  a,  Order,  v: Vector a``

	Return Type: ``Tree a``

.. wake:function:: def vectorToTree cmp v

	Convert a Vector to a Tree.
	

	Parameters: ``cmp: a,  a,  Order,  v: Vector a``

	Return Type: ``Tree a``

.. wake:function:: def tlen (Tree _ root)

	Returns the total length of the Tree.
	

	Parameters: ``Tree a``

	Return Type: ``Integer``

.. wake:function:: def tempty (Tree _ root)

	Returns True if the Tree is empty, False otherwise.
	

	Parameters: ``Tree a``

	Return Type: ``Boolean``

.. wake:function:: def tinsert y (Tree cmp root)

	Insert y into the tree only if no other keys = y
	

	Parameters: ``a,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tinsertReplace y (Tree cmp root)

	Insert y into the tree, removing any existing keys = y
	

	Parameters: ``a,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tinsertMulti y (Tree cmp root)

	Insert y into the tree at the lowest rank of keys = y
	

	Parameters: ``a,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def a ⊆ b

	Returns True if a is a subset of b, otherwise False.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def a ⊇ b

	Returns True if a is a superset of b, otherwise False.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def a ⊉ b

	Returns True if a is NOT a superset of b, otherwise False.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def a ⊈ b

	Returns True if a is NOT a subset of b, otherwise False.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def a ⊊ b

	Returns True if a is a proper subset of b, otherwise False.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def a ⊋ b

	Returns True if a is a proper superset of b, otherwise False.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def tsubset (Tree _ aroot) (Tree cmp broot)

	Returns True if every element of a is also in b, otherwise false.
	

	Parameters: ``Tree a,  Tree a``

	Return Type: ``Boolean``

.. wake:function:: def tdelete y (Tree cmp root)

	Deletes all keys that are equal to y.
	

	Parameters: ``a,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tfoldl f a (Tree _ root)

	Folds from left to right.
	

	Parameters: ``a,  b,  a,  a,  Tree b``

	Return Type: ``a``

.. wake:function:: def tfoldr f a (Tree _ root)

	Folds from right to left.
	

	Parameters: ``a,  b,  b,  b,  Tree a``

	Return Type: ``b``

.. wake:function:: def tfoldmap f a g (Tree _ root)

	Fold in parallel; assumes f is an associative operator and has type: a => a => a
	

	Parameters: ``a,  a,  a,  b,  b,  a,  Tree b``

	Return Type: ``a``

.. wake:function:: def tfold f a t

	No description for this feature yet.

	Parameters: ``f: a,  a,  a,  a: a,  t: Tree a``

	Return Type: ``a``

.. wake:function:: def treeToList

	Converts a Tree to a List.
	

	Parameters: ``Tree a``

	Return Type: ``List a``

.. wake:function:: def tappi f (Tree _ root)

	No description for this feature yet.

	Parameters: ``Integer,  a,  b,  Tree a``

	Return Type: ``Unit``

.. wake:function:: def tat i (Tree _ root)

	Extract the i-th ranked element
	

	Parameters: ``Integer,  Tree a``

	Return Type: ``Option a``

.. wake:function:: def tsplitAt i (Tree cmp root)

	Split elements ranked [0,i) and [i,inf) into two trees
	

	Parameters: ``Integer,  Tree a``

	Return Type: ``Pair (Tree a) (Tree a)``

.. wake:function:: def ttake i t

	No description for this feature yet.

	Parameters: ``i: Integer,  t: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tdrop i t

	No description for this feature yet.

	Parameters: ``i: Integer,  t: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tfind f (Tree _ root)

	Lowest rank element where f x = True  => Option (Pair x rank)
	

	Parameters: ``a,  Boolean,  Tree a``

	Return Type: ``Option (Pair a Integer)``

.. wake:function:: def tsplitUntil f t

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  t: Tree a``

	Return Type: ``Pair (Tree a) (Tree a)``

.. wake:function:: def ttakeUntil f t

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  t: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tdropUntil f t

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  t: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def texists f t

	Returns True if there exists an x in t where f x = True
	

	Parameters: ``f: a,  Boolean,  t: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def tforall f t

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  t: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def tsplit y (Tree cmp root)

	Split tree into those elements <, =, and > y
	

	Parameters: ``a,  Tree a``

	Return Type: ``Triple (Tree a) (Tree a) (Tree a)``

.. wake:function:: def tsplitBy f (Tree cmp root)

	Split tree into those elements where f x = True and those where f x = False
	

	Parameters: ``a,  Boolean,  Tree a``

	Return Type: ``Pair (Tree a) (Tree a)``

.. wake:function:: def tfilter f (Tree cmp root)

	Remove all elements x such that f x = False.
	

	Parameters: ``a,  Boolean,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tmin (Tree _ root)

	Return the smallest element in the tree.
	

	Parameters: ``Tree a``

	Return Type: ``Option a``

.. wake:function:: def tmax (Tree _ root)

	Return the largest element in the tree.
	

	Parameters: ``Tree a``

	Return Type: ``Option a``

.. wake:function:: def tlowerGE y (Tree cmp root)

	Lowest rank element with x >= y.
	

	Parameters: ``a,  Tree a``

	Return Type: ``Option (Pair a Integer)``

.. wake:function:: def tlowerGT y (Tree cmp root)

	Lowest rank element with x > y.
	

	Parameters: ``a,  Tree a``

	Return Type: ``Option (Pair a Integer)``

.. wake:function:: def tupperLT y (Tree cmp root)

	Highest rank element with x < y
	

	Parameters: ``a,  Tree a``

	Return Type: ``Option (Pair a Integer)``

.. wake:function:: def tupperLE y (Tree cmp root)

	Highest rank element with x <= y
	

	Parameters: ``a,  Tree a``

	Return Type: ``Option (Pair a Integer)``

.. wake:function:: def tequal y (Tree cmp root)

	=> Pair (matches: List x) (rank: Integer)
	Extract all elements from the tree which are equal to y
	

	Parameters: ``a,  Tree a``

	Return Type: ``Pair (List a) Integer``

.. wake:function:: def x ∈ y

	Returns True if x is an element of y, False otherwise.
	

	Parameters: ``x: a,  y: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def x ∉ y

	Returns True if x is NOT an element of y, False otherwise.
	

	Parameters: ``x: a,  y: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def x ∋ y

	Returns True if x contains y, False otherwise.
	

	Parameters: ``x: Tree a,  y: a``

	Return Type: ``Boolean``

.. wake:function:: def x ∌ y

	Returns True if x does NOT contain y, False otherwise.
	

	Parameters: ``x: Tree a,  y: a``

	Return Type: ``Boolean``

.. wake:function:: def tcontains y t

	No description for this feature yet.

	Parameters: ``y: a,  t: Tree a``

	Return Type: ``Boolean``

.. wake:function:: def tdistinctBy cmp t

	Eliminate duplicates, as identified by cmp
	

	Parameters: ``cmp: a,  a,  Order,  t: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tdistinctRunBy f t

	Eliminate duplicates, as identified by f
	

	Parameters: ``f: a,  a,  Boolean,  t: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def a ∪ b

	Returns the union of trees a and b, keeps only values from a if they are equal to values in b.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tunion (Tree _ aroot) (Tree cmp broot)

	Returns the union of two trees, given their roots.
	

	Parameters: ``Tree a,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def a ⊎ b

	Union of two trees, keeping equal values of a before equal values of b
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tunionMulti (Tree _ aroot) (Tree cmp broot)

	No description for this feature yet.

	Parameters: ``Tree a,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def a ∖ b

	Returns the set difference of A and B, that is, a tree containing all elements of A which are not in B.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tsubtract (Tree _ aroot) (Tree cmp broot)

	No description for this feature yet.

	Parameters: ``Tree a,  Tree a``

	Return Type: ``Tree a``

.. wake:function:: def a ∩ b

	Returns a tree containing all elements of A which are also in B.
	

	Parameters: ``a: Tree a,  b: Tree a``

	Return Type: ``Tree a``

.. wake:function:: def tintersect (Tree _ aroot) (Tree cmp broot)

	No description for this feature yet.

	Parameters: ``Tree a,  Tree a``

	Return Type: ``Tree a``

order.wake
----------
.. wake:data:: data Order

	``GT`` = Greater Than
	``EQ`` = Equal
	``LT`` = Less Than
	Can hold the following values:
	Used for comparing quantities.
	

.. wake:function:: def isLT

	Returns ``True`` if less than, otherwise ``False``.
	

	Parameters: ``Order``

	Return Type: ``Boolean``

.. wake:function:: def isEQ

	Returns ``True`` if equal, otherwise ``False``.
	

	Parameters: ``Order``

	Return Type: ``Boolean``

.. wake:function:: def isGT

	Returns ``True`` if greater than, otherwise ``False``.
	

	Parameters: ``Order``

	Return Type: ``Boolean``

.. wake:function:: def isLE

	Returns ``True`` if less or equal, otherwise ``False``.
	

	Parameters: ``Order``

	Return Type: ``Boolean``

.. wake:function:: def isNE

	Returns ``True`` if not equal, otherwise ``False``.
	

	Parameters: ``Order``

	Return Type: ``Boolean``

.. wake:function:: def isGE

	Returs ``True`` if greater or equal, otherwise ``False``.
	

	Parameters: ``Order``

	Return Type: ``Boolean``

list.wake
---------
.. wake:data:: data List a

	Constructs a List object.
	

.. wake:function:: def empty

	Returns True if the list contains no elements, otherwise False.
	

	Parameters: ``List a``

	Return Type: ``Boolean``

.. wake:function:: def head

	Returns the first element of the list.
	

	Parameters: ``List a``

	Return Type: ``Option a``

.. wake:function:: def tail

	Returns a list of all elements, starting from the second.
	

	Parameters: ``List a``

	Return Type: ``List a``

.. wake:function:: def map f

	Applies a function f to each element of the list.
	

	Parameters: ``f: a,  b,  List a``

	Return Type: ``List b``

.. wake:function:: def mapFlat f

	(f: a => List b) => List a => List b
	Applies a function to each element of the List and builds a new List from the resulting elements
	

	Parameters: ``f: a,  List b,  List a``

	Return Type: ``List b``

.. wake:function:: def mapPartial f

	No description for this feature yet.

	Parameters: ``f: a,  Option b,  List a``

	Return Type: ``List b``

.. wake:function:: def foldl f a

	No description for this feature yet.

	Parameters: ``f: a,  b,  a,  a: a,  List b``

	Return Type: ``a``

.. wake:function:: def scanl f a

	No description for this feature yet.

	Parameters: ``f: a,  b,  a,  a: a,  List b``

	Return Type: ``List a``

.. wake:function:: def foldr f a

	No description for this feature yet.

	Parameters: ``f: a,  b,  b,  a: b,  List a``

	Return Type: ``b``

.. wake:function:: def scanr f a

	No description for this feature yet.

	Parameters: ``f: a,  Option b,  b,  a: b,  List a``

	Return Type: ``List b``

.. wake:function:: def l ++ r

	Concatenates two ``List``s.
	

	Parameters: ``l: List a,  r: List a``

	Return Type: ``List a``

.. wake:function:: def reverse l

	Reverses the order of the elements of a ``List``.
	

	Parameters: ``l: List a``

	Return Type: ``List a``

.. wake:function:: def flatten l

	Flattens a ``List``, that is, replaces all sub-``Lists`` with their elements (removing all sub-``List`` boundaries).
	

	Parameters: ``l: List List a``

	Return Type: ``List a``

.. wake:function:: def len l

	Returns the number of entries in a ``List``.
	

	Parameters: ``l: List a``

	Return Type: ``Integer``

.. wake:function:: def splitAt i l

	Splits a ``List`` into two ``List``s, with the first containing the first ``i`` elements and the second containing the rest.
	

	Parameters: ``i: Integer,  l: List a``

	Return Type: ``Pair (List a) (List a)``

.. wake:function:: def take i l

	Returns the first ``i`` elements of a ``List``.
	

	Parameters: ``i: Integer,  l: List a``

	Return Type: ``List a``

.. wake:function:: def drop i l

	Removes the first ``i`` elements of a ``List``.
	

	Parameters: ``i: Integer,  l: List a``

	Return Type: ``List a``

.. wake:function:: def at i l

	Returns the ``i``th character in the ``List``.
	

	Parameters: ``i: Integer,  l: List a``

	Return Type: ``Option a``

.. wake:function:: def splitUntil f l

	The second starts with the first element of ``l`` satisfying ``f`` and contains the rest of the elements of ``l``.
	The first contains all elements of ``l`` up to, but not including, the first element of ``l`` satisfying ``f``.
	Returns a pair of ``List``s.
	

	Parameters: ``f: a,  Boolean,  l: List a``

	Return Type: ``Pair (List a) (List a)``

.. wake:function:: def takeUntil f l

	Returns ``True``
	

	Parameters: ``f: a,  Boolean,  l: List a``

	Return Type: ``List a``

.. wake:function:: def dropUntil f l

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  l: List a``

	Return Type: ``List a``

.. wake:function:: def find f

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  List a``

	Return Type: ``Option (Pair a Integer)``

.. wake:function:: def exists f l

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  l: List a``

	Return Type: ``Boolean``

.. wake:function:: def forall f l

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  l: List a``

	Return Type: ``Boolean``

.. wake:function:: def splitBy f

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  List a``

	Return Type: ``Pair (List a) (List a)``

.. wake:function:: def filter f l

	No description for this feature yet.

	Parameters: ``f: a,  Boolean,  l: List a``

	Return Type: ``List a``

.. wake:function:: def transpose l

	Tranposition is only it's own inverse when the lists have non-increasing size
	

	Parameters: ``l: List List a``

	Return Type: ``List (List a)``

.. wake:function:: def sortBy f l

	f should be a less-than comparison
	

	Parameters: ``f: a,  a,  Boolean,  l: List a``

	Return Type: ``List a``

.. wake:function:: def distinctBy cmp

	keep only the first occurrence of a value
	

	Parameters: ``cmp: a,  a,  Order,  List a``

	Return Type: ``List a``

.. wake:function:: def distinctRunBy f l

	keep only the first occurrence in a run of equal values
	f should be an equality comparison
	

	Parameters: ``f: a,  a,  Boolean,  l: List a``

	Return Type: ``List a``

.. wake:function:: def cmp f

	No description for this feature yet.

	Parameters: ``f: a,  b,  Order,  List a,  List b``

	Return Type: ``Order``

.. wake:function:: def tab f n

	No description for this feature yet.

	Parameters: ``f: Integer,  a,  n: Integer``

	Return Type: ``List a``

.. wake:function:: def seq

	No description for this feature yet.

	Parameters: ``n: Integer``

	Return Type: ``List Integer``

.. wake:function:: def zip

	If one ``List`` is longer than the other, the later elements of the longer ``List`` will be omitted.
	The nth ``Pair`` in the ``List`` contains the nth element of each ``List``.
	Transforms two ``List``s into a ``List`` of ``Pair``s.
	

	Parameters: ``List a,  List b``

	Return Type: ``List (Pair a b)``

.. wake:function:: def unzip

	No description for this feature yet.

	Parameters: ``List Pair a b``

	Return Type: ``Pair (List a) (List b)``

json.wake
---------
.. wake:data:: data JValue

	Can hold either a String, Integer, Double, Boolean, Object, Array, or nothing (Null)
	The JSON data type.
	

.. wake:function:: def getJString

	Returns ``None`` otherwise.
	Extracts a ``String`` from a ``JValue``, if it is either a ``JString`` or a ``JArray`` containing exactly one ``JString``.
	

	Parameters: ``JValue``

	Return Type: ``Option String``

.. wake:function:: def getJInteger

	Returns ``None`` otherwise.
	Extracts an ``Integer`` from a ``JValue``, if it is either a ``JInteger`` or a ``JArray`` containing exactly one ``JString``.
	

	Parameters: ``JValue``

	Return Type: ``Option Integer``

.. wake:function:: def getJDouble

	Returns ``None`` otherwise.
	Extracts a ``Double`` from a ``JValue``, if it is either a ``JDouble`` or ``JInteger``, or a ``JArray`` containing exactly one ``JDouble`` or ``JInteger``.
	

	Parameters: ``JValue``

	Return Type: ``Option Double``

.. wake:function:: def getJBoolean

	Returns ``None`` otherwise.
	Extracts a ``Boolean`` from a ``JValue``, if it is either a ``JBoolean`` or a ``JArray`` containing exactly one ``JBoolean``.
	

	Parameters: ``JValue``

	Return Type: ``Option Boolean``

.. wake:function:: def getJObject

	Returns ``None`` otherwise.
	Extracts a ``List`` of ``String, JValue`` ``Pair``s representing the provided ``JValue``, if it is a ``JObject`` or ``JArray`` containing exactly one ``JObject``.
	

	Parameters: ``JValue``

	Return Type: ``Option (List (Pair String JValue))``

.. wake:function:: def getJArray

	Returns ``None`` otherwise.
	Extracts a ``List`` from a ``JValue``, if it is a ``JArray``.
	

	Parameters: ``JValue``

	Return Type: ``Option (List JValue)``

.. wake:function:: def parseJSONBody body

	No description for this feature yet.

	Parameters: ``body: String``

	Return Type: ``Result JValue String``

.. wake:function:: def parseJSONFile path

	No description for this feature yet.

	Parameters: ``path: Path``

	Return Type: ``Result JValue Error``

.. wake:function:: def jsonEscape str

	No description for this feature yet.

	Parameters: ``str: String``

	Return Type: ``String``

.. wake:function:: def prettyJSONFormat

	No description for this feature yet.

	Parameters: None

	Return Type: ``JSONFormat``

.. wake:function:: def customFormatJSON fmt body

	No description for this feature yet.

	Parameters: ``fmt: JSONFormat,  body: JValue``

	Return Type: ``String``

.. wake:function:: def formatJSON

	No description for this feature yet.

	Parameters: ``body: JValue``

	Return Type: ``String``

.. wake:function:: def prettyJSON

	No description for this feature yet.

	Parameters: ``body: JValue``

	Return Type: ``String``

.. wake:function:: def x /| f

	No description for this feature yet.

	Parameters: ``x: JValue,  f: JValue,  Boolean``

	Return Type: ``JValue``

.. wake:function:: def root /../ filterFn

	No description for this feature yet.

	Parameters: ``root: JValue,  filterFn: JValue,  Boolean``

	Return Type: ``JValue``

.. wake:function:: def x // y

	No description for this feature yet.

	Parameters: ``x: JValue,  y: RegExp``

	Return Type: ``JValue``

.. wake:function:: def x ==/ y

	Tests the equality of two ``JValue``s, using the appropriate comparison operator depending on the types being compared.
	

	Parameters: ``x: JValue,  y: JValue``

	Return Type: ``Boolean``

tuple.wake
----------
.. wake:data:: data Unit

	unit / void
	

.. wake:tuple:: tuple Pair a b

	Creates a ``Pair``, a tuple containing two elements.
	

	Parameters: ``Second: a,  Pair b c``

	Return Type: ``Pair b a``

.. wake:function:: def x → y

	Defines an arrow operator as an alternate way to initialize a ``Pair``.
	

	Parameters: ``x: a,  y: b``

	Return Type: ``Pair a b``

.. wake:tuple:: tuple Triple a b c

	Creates a ``Triple``, a tuple containing three elements.
	

	Parameters: ``Third: a,  Triple b c d``

	Return Type: ``Triple b c a``

