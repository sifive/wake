-------------------------
share/doc/wake/syntax/vim
-------------------------

.. toctree::
	syntax/syntax.rst
	ftdetect/ftdetect.rst


