---------------------
share/doc/wake/syntax
---------------------

.. toctree::
	emacs/emacs.rst
	vim/vim.rst
	joe/joe.rst


