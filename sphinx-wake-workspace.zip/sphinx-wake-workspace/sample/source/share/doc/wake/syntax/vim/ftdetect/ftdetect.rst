----------------------------------
share/doc/wake/syntax/vim/ftdetect
----------------------------------

.. toctree::


