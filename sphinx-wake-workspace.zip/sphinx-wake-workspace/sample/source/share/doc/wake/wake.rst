--------------
share/doc/wake
--------------

.. toctree::
	syntax/syntax.rst


